<?php include "db.php"; ?>

<!DOCTYPE html>
<html>
<head>
<title>Add a Class</title>
</head>
<body>

<h2>Add a Class</h2>

<form method="POST">
    <label>Select a Course:</label><br>

    <select name="course_id">
        <?php
        $sql = "SELECT * FROM courses";
        $result = $conn->query($sql);

        while ($row = $result->fetch_assoc()) {
            echo "<option value='" . $row['id'] . "'>"
                  . $row['course_name'] . " (" . $row['course_code'] . ")</option>";
        }
        ?>
    </select>

    <br><br>
    <button type="submit" name="submit">Register Class</button>
</form>

<?php
if (isset($_POST['submit'])) {
    $course_id = $_POST['course_id'];
    $user_id = 1;

    $sql = "INSERT INTO registrations (user_id, course_id)
            VALUES ('$user_id', '$course_id')";

    if ($conn->query($sql) === TRUE) {
        echo "<p>Class added successfully.</p>";
    } else {
        echo "Error: " . $conn->error;
    }
}
?>

</body>
</html>
