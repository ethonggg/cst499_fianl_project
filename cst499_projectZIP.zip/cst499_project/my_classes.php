<?php include "db.php"; ?>

<!DOCTYPE html>
<html>
<head>
<title>My Classes</title>
</head>
<body>

<h2>My Registered Classes</h2>

<?php
// Hardcoded user for assignment purposes
$user_id = 1;

$sql = "SELECT courses.course_name, courses.course_code
        FROM registrations
        JOIN courses ON registrations.course_id = courses.id
        WHERE registrations.user_id = $user_id";

$result = $conn->query($sql);

if ($result->num_rows > 0) {
    echo "<ul>";
    while($row = $result->fetch_assoc()) {
        echo "<li>" . $row["course_name"] . " (" . $row["course_code"] . ")</li>";
    }
    echo "</ul>";
} else {
    echo "You are not registered for any classes.";
}
?>

</body>
</html>
