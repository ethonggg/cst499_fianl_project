<?php 
include "db.php"; 
?>

<!DOCTYPE html>
<html>
<head>
    <title>Register for a Class</title>
</head>
<body>

<h2>Register for a Class</h2>

<form method="POST">

    <label>Select a Course:</label><br><br>

    <select name="course_id" required>
        <?php
        $sql = "SELECT * FROM courses";
        $result = $conn->query($sql);

        while ($row = $result->fetch_assoc()) {
            echo "<option value='" . $row['id'] . "'>" . $row['course_name'] . " (" . $row['course_code'] . ")</option>";
        }
        ?>
    </select>

    <br><br>

    <button type="submit" name="register_class">Register</button>
</form>

<?php
if (isset($_POST['register_class'])) {

    // Hard-coded user for now (assignment does not require login working yet)
    $user_id = 1;

    $course_id = $_POST['course_id'];

    $sql = "INSERT INTO registrations (user_id, course_id) VALUES ('$user_id', '$course_id')";

    if ($conn->query($sql) === TRUE) {
        echo "Class registered successfully.";
    } else {
        echo "Error: " . $conn->error;
    }
}
?>

</body>
</html>
