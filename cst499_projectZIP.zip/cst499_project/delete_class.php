<?php include "db.php"; ?>

<!DOCTYPE html>
<html>
<head>
<title>Delete Class</title>
</head>
<body>

<h2>Delete a Registered Class</h2>

<form method="POST">
    <label>Select a Class to Delete:</label><br>

    <select name="registration_id">
        <?php
        $user_id = 1;
        $sql = "SELECT registrations.id, courses.course_name, courses.course_code
                FROM registrations
                JOIN courses ON registrations.course_id = courses.id
                WHERE registrations.user_id = $user_id";

        $result = $conn->query($sql);

        while ($row = $result->fetch_assoc()) {
            echo "<option value='" . $row['id'] . "'>"
                  . $row['course_name'] . " (" . $row['course_code'] . ")</option>";
        }
        ?>
    </select>

    <br><br>
    <button type="submit" name="delete">Delete Class</button>
</form>

<?php
if (isset($_POST['delete'])) {
    $registration_id = $_POST['registration_id'];

    $sql = "DELETE FROM registrations WHERE id = $registration_id";

    if ($conn->query($sql) === TRUE) {
        echo "<p>Class removed successfully.</p>";
    } else {
        echo "Error: " . $conn->error;
    }
}
?>

</body>
</html>
