<?php include "db.php"; ?>

<!DOCTYPE html>
<html>
<head>
<title>Register</title>
</head>
<body>

<h2>User Registration</h2>

<form method="POST">
  Full Name: <input type="text" name="full_name" required><br><br>
  Email: <input type="email" name="email" required><br><br>
  Phone: <input type="text" name="phone"><br><br>
  Password: <input type="password" name="password" required><br><br>
  <button type="submit" name="submit">Register</button>
</form>

<?php
if (isset($_POST['submit'])) {
    $full_name = $_POST['full_name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

    $sql = "INSERT INTO users (full_name, email, phone, password_hash)
            VALUES ('$full_name', '$email', '$phone', '$password')";

    if ($conn->query($sql) === TRUE) {
        echo "Registration successful.";
    } else {
        echo "Error: " . $conn->error;
    }
}
?>

</body>
</html>
