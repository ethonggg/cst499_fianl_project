<!DOCTYPE html>
<html>
<head>
<title>Course Portal</title>
</head>
<body>
<h2>Welcome to the Course Portal</h2>

<a href="register.php">Register</a> |
<a href="login.php">Login</a>

</body>
</html>
